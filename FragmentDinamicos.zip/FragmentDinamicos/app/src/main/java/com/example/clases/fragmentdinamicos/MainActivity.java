package com.example.clases.fragmentdinamicos;

import android.net.Uri;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements
        HomeFragment.OnFragmentInteractionListener,
        SumaFragment.OnFragmentInteractionListener,
        RestaFragment.OnFragmentInteractionListener,
        ProdFragment.OnFragmentInteractionListener,
        DivFragment.OnFragmentInteractionListener {

    HomeFragment hf;
    SumaFragment sf;
    RestaFragment rf;
    ProdFragment pf;
    DivFragment df;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hf = new HomeFragment();
        sf = new SumaFragment();
        rf = new RestaFragment();
        pf = new ProdFragment();
        df = new DivFragment();

        getSupportFragmentManager().beginTransaction().add(R.id.idContenedor, hf).commit();
    }

    public void onFragmentInteraction(Uri uri){

    }

    public void ocBtn(View view){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        switch (view.getId()){
            case R.id.btnHome:
                ft.replace(R.id.idContenedor, hf);
                break;
            case R.id.btnSuma:
                ft.replace(R.id.idContenedor, sf);
                break;
            case R.id.btnResta:
                ft.replace(R.id.idContenedor, rf);
                break;
            case R.id.btnProd:
                ft.replace(R.id.idContenedor, pf);
                break;
            case R.id.btnDiv:
                ft.replace(R.id.idContenedor, df);
                break;
        }
        ft.commit();
    }

    static public double sumar(){
       return 0;
    }


}
