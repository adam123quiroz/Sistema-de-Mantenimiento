package com.q.calculadora;


import android.widget.Toast;

public class Calculadora {

    private double n1;
    private double n2;
    private MainActivity s;

    public Calculadora(double n1, double n2) {
        this.n1 = n1;
        this.n2 = n2;
    }
    public Calculadora() {
        n1 = 0.0;
        n2 = 0.0;
    }//end class constructor//end class constructor

    public double getN1() {
        return n1;
    }

    public double getN2() {
        return n2;
    }

    public void setN1(double n1) {
        try {
            this.n1 = n1;
        } catch(Exception e) {
            Toast.makeText(s.getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }

    }

    public void setN2(double n2) {
        try {
            this.n2 = n2;
        } catch(Exception e) {
            Toast.makeText(s.getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }
    }

    public MainActivity getS() {
        return s;
    }

    public void setS(MainActivity s) {
        this.s = s;
    }

    public double sumar() {
        double result = 0;
        try {
            result = n1 + n2;
        } catch (Exception e) {
            Toast.makeText(s.getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }
        return result;
    }

    public double restar() {
        double result = 0;
        try {
            result = n1 - n2;
        } catch (Exception e) {
            Toast.makeText(s.getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }
        return result;
    }

    public double multiplicar() {
        double result = 0;
        try {
            result = n1 * n2;
        } catch (Exception e) {
            Toast.makeText(s.getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }
        return result;
    }

    public double dividir() {
        double result = 0;
        try {
            if(n2 == 0){
                Toast.makeText(s.getApplicationContext(),"No Puede Dividir con Cero",Toast.LENGTH_LONG).show();
            } else {
                result = n1 / n2;
            }
        } catch (Exception e) {
            Toast.makeText(s.getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }
        return result;
    }
}
