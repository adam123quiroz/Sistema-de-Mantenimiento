package com.q.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText texto1, texto2;
    TextView textoResultado;
    Calculadora c;
    double[] numeros;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texto1 = findViewById(R.id.etN1);
        texto2 = findViewById(R.id.etN2);
        textoResultado = findViewById(R.id.tvResult);
        c = new Calculadora();
    }

    public void limpiar(View view) {
        texto1.setText("");
        texto2.setText("");
        textoResultado.setText("");
    }
    public void sumar(View view) {
        numeros = rescatarNumeros();
        c.setN1(numeros[0]);
        c.setN2(numeros[1]);
        imprimirTextView(c.sumar());
    }
    public void restar(View view) {
        numeros = rescatarNumeros();
        c.setN1(numeros[0]);
        c.setN2(numeros[1]);
        imprimirTextView(c.restar());
    }
    public void multiplicar(View view) {
        numeros = rescatarNumeros();
        c.setN1(numeros[0]);
        c.setN2(numeros[1]);
        imprimirTextView(c.multiplicar());
    }
    public void dividir(View view) {
        numeros = rescatarNumeros();
        c.setN1(numeros[0]);
        c.setN2(numeros[1]);
        imprimirTextView(c.dividir());
    }
    private double[] rescatarNumeros() {
        double n[] = new double[2];
        try {
            c.setS(this);
            double n1 = Double.parseDouble(texto1.getText().toString());
            double n2 = Double.parseDouble(texto2.getText().toString());
            n[0] = n1;
            n[1] = n2;
        }catch (Exception e){
            Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
        }
        return n;
    }

    private void imprimirTextView(double s) {
        textoResultado.setText(String.format("%.2f",s));
    }
}
