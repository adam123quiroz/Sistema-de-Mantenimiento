package com.fragment;

import android.net.Uri;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements
        RojoFragment.OnFragmentInteractionListener,
        VerdeFragment.OnFragmentInteractionListener,
        AmarilloFragment.OnFragmentInteractionListener,
        AzulFragment.OnFragmentInteractionListener,
        Comunicador {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void enviaRV(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        VerdeFragment vf = (VerdeFragment) fm.findFragmentById(R.id.idVerde);
        vf.recibeFR(dato);
    }

    @Override
    public void enviaRAm(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        AmarilloFragment rf = (AmarilloFragment) fm.findFragmentById(R.id.idAmarillo);
        rf.recibeFR(dato);
    }

    @Override
    public void enviaRA(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        AzulFragment af = (AzulFragment) fm.findFragmentById(R.id.idAzul);
        af.recibeFR(dato);
    }

    @Override
    public void enviaVR(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        RojoFragment rf = (RojoFragment) fm.findFragmentById(R.id.idRojo);
        rf.recibeFR(dato);
    }

    @Override
    public void enviaVAm(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        AmarilloFragment rf = (AmarilloFragment) fm.findFragmentById(R.id.idAmarillo);
        rf.recibeFR(dato);
    }

    @Override
    public void enviaVA(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        AzulFragment af = (AzulFragment) fm.findFragmentById(R.id.idAzul);
        af.recibeFR(dato);
    }

    @Override
    public void enviaAmR(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        RojoFragment rf = (RojoFragment) fm.findFragmentById(R.id.idRojo);
        rf.recibeFR(dato);
    }

    @Override
    public void enviaAmV(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        VerdeFragment vf = (VerdeFragment) fm.findFragmentById(R.id.idVerde);
        vf.recibeFR(dato);
    }

    @Override
    public void enviaAmA(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        AzulFragment af = (AzulFragment) fm.findFragmentById(R.id.idAzul);
        af.recibeFR(dato);
    }

    @Override
    public void enviaAAm(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        AmarilloFragment rf = (AmarilloFragment) fm.findFragmentById(R.id.idAmarillo);
        rf.recibeFR(dato);
    }

    @Override
    public void enviaAR(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        RojoFragment rf = (RojoFragment) fm.findFragmentById(R.id.idRojo);
        rf.recibeFR(dato);
    }

    @Override
    public void enviaAV(Registro dato) {
        FragmentManager fm = getSupportFragmentManager();
        VerdeFragment vf = (VerdeFragment) fm.findFragmentById(R.id.idVerde);
        vf.recibeFR(dato);
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
