package com.fragment;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class AzulFragment extends Fragment implements View.OnClickListener{

    Comunicador comunica;
    RadioButton r1, r2, r3;
    EditText editTextDato1;
    EditText editTextDato2;
    Button enviar;
    private OnFragmentInteractionListener mListener;

    public AzulFragment() {
        // Required empty public constructor
    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        comunica = (Comunicador) getActivity();
        editTextDato1 = (EditText) getActivity().findViewById(R.id.AetDato1);
        editTextDato2 = (EditText) getActivity().findViewById(R.id.AetDato2);
        r1 = (RadioButton) getActivity().findViewById(R.id.ARbtnF1);
        r2 = (RadioButton) getActivity().findViewById(R.id.ARbtnF2);
        r3 = (RadioButton) getActivity().findViewById(R.id.ARbtnF4);
        enviar = (Button) getActivity().findViewById(R.id.AbtnEnviar);
        enviar.setOnClickListener(this);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_azul, container, false);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onClick(View v) {
        Registro r = new Registro(editTextDato1.getText().toString(),
                editTextDato2.getText().toString());
        if (r1.isChecked()){
            comunica.enviaAR(r);
        }
        if (r2.isChecked()){
            comunica.enviaAV(r);
        }
        if (r3.isChecked()){
            comunica.enviaAAm(r);
        }
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    public void recibeFR(Registro r) {
        editTextDato1.setText(r.getDato1());
        editTextDato2.setText(r.getDato2());

    }
}
