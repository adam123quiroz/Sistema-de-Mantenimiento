package com.fragment;

public interface Comunicador {

    void enviaRV(Registro dato);
    void enviaRAm(Registro dato);
    void enviaRA(Registro dato);

    void enviaVR(Registro dato);
    void enviaVAm(Registro dato);
    void enviaVA(Registro dato);

    void enviaAmR(Registro dato);
    void enviaAmV(Registro dato);
    void enviaAmA(Registro dato);

    void enviaAAm(Registro dato);
    void enviaAR(Registro dato);
    void enviaAV(Registro dato);


}//fin de las interfaces
